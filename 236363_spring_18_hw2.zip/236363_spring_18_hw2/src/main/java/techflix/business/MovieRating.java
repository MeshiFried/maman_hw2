package techflix.business;

public enum MovieRating {
    LIKE, DISLIKE
}
