package techflix.business;

public enum ReturnValue {
    OK, NOT_EXISTS, ALREADY_EXISTS,  ERROR, BAD_PARAMS
}
